"""why are you here"""
from .main import console, __version__